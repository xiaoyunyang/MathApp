cocos2d logos made by Michael Heald from Fully Illustrated ( http://www.fullyillustrated.com )

 * You can use any of these logos in your game.
 * Or You can use any other logo if you want (eg: http://www.cocos2d-iphone.org/wiki/doku.php/resources:logos )
 * Or, if you don't want to display any logo, you can do it as well.

But if you decide to use any of these logos, please, display it in it's original form (you can scale it down or up if you want) but don't alter them.
