//
// cocos2d performance particle test
// Based on the test by Valentin Milea
//
#import <UIKit/UIKit.h>

@interface AppController
: NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@end
